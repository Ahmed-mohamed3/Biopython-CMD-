from Bio import SeqIO
from Bio import pairwise2
from Bio.SubsMat import MatrixInfo as matlist

def get_alignments(fasta_file1, fasta_file2, output_file=None):
  # Read sequences from fasta files
  seq1 = SeqIO.read(fasta_file1, 'fasta').seq
  seq2 = SeqIO.read(fasta_file2, 'fasta').seq

  matrix = matlist.blosum62

  # Perform global alignment
  alignments = pairwise2.align.globalds(seq1, seq2, matrix, -10, -0.5)

  # Print alignments and scores
  if output_file:
    with open(output_file, 'w') as f:
      for alignment in alignments:
        score = alignment[2]
        a = alignment[0]
        b = alignment[1]
        f.write(f"Score: {score}\n")
        f.write(f"{a}\n")
        f.write(f"{b}\n")
  else:
    for alignment in alignments:
      score = alignment[2]
      a = alignment[0]
      b = alignment[1]
      print(f"Score: {score}")
      print(f"{a}")
      print(f"{b}")
get_alignments(r'F:\sana 4\biopython\test\file1.fasta', r'F:\sana 4\biopython\test\file1.fasta')